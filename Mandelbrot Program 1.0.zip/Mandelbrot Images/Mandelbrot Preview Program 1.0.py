from os import path as OSPath
import math
import time
import tkinter as TTK
from numba import njit

Current_Program_Location = f"{OSPath.dirname(OSPath.realpath(__file__))}"

## Returns an int that is rounded properly mathmatically from a float e.g. 254.75 is returned as 255 instead of 254 which is what int(254.75) would return
def Round_Float_To_Int(Float_To_Round):
    if Float_To_Round - int(Float_To_Round) <.5:
        return int(Float_To_Round)
    else:
        return int(Float_To_Round)+1
 
## This takes in a tuple of HSV values and returns a converted List of RGB values
def Convert_HSV_To_RGB(
    Starting_Val_Hue:float,
    Starting_Val_Sat:float,
    Starting_Val_Value:float
    ):
 
    Starting_Val_Hue = Starting_Val_Hue%360
    Starting_Val_Hue_Mod = Starting_Val_Hue%60
 
    if Starting_Val_Sat > 255:
        Starting_Val_Sat = 255
    elif Starting_Val_Sat < 0:
        Starting_Val_Sat = 0
 
    if Starting_Val_Value > 255:
        Starting_Val_Value = 255
    elif Starting_Val_Value < 0:
        Starting_Val_Value = 0
 
    if Starting_Val_Hue >=0 and Starting_Val_Hue < 60:
 
        Temp_Val = 255/60*Starting_Val_Hue_Mod
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (                                                                ## These are the same for each return
            Round_Float_To_Int(Starting_Val_Value),                             ## Red value
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255),                ## Green value
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255)   ## Blue Value
        )
 
    elif Starting_Val_Hue >=60 and Starting_Val_Hue < 120:
 
        Temp_Val = 255/60*(60-Starting_Val_Hue_Mod)
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255),
            Round_Float_To_Int(Starting_Val_Value),
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255)
        )
 
    elif Starting_Val_Hue >=120 and Starting_Val_Hue < 180:
 
        Temp_Val = 255/60*Starting_Val_Hue_Mod
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255),
            Round_Float_To_Int(Starting_Val_Value),
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255)
        )
   
    elif Starting_Val_Hue >=180 and Starting_Val_Hue < 240:
       
        Temp_Val = 255/60*(60-Starting_Val_Hue_Mod)
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255),
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255),
            Round_Float_To_Int(Starting_Val_Value)
        )
 
    elif Starting_Val_Hue >=240 and Starting_Val_Hue < 300:
 
        Temp_Val = 255/60*Starting_Val_Hue_Mod
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255),
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255),
            Round_Float_To_Int(Starting_Val_Value)
        )
   
    elif Starting_Val_Hue >=300 and Starting_Val_Hue < 360:
 
        Temp_Val = 255/60*(60-Starting_Val_Hue_Mod)
        Temp_Val = Temp_Val+(255-Temp_Val)*(255-Starting_Val_Sat)/255
 
        return (
            Round_Float_To_Int(Starting_Val_Value),
            Round_Float_To_Int((255-Starting_Val_Sat)*Starting_Val_Value/255),
            Round_Float_To_Int(Temp_Val*Starting_Val_Value/255)
        )
 
## Simply returns values that are converted into ints and are always at least 0 and at most 255
def Bounding_RGB_Values(RGB_Values):

    New_RGB_Values = [0 if RGB_Values[a] < 0 else 255 if RGB_Values[a] > 255 else Round_Float_To_Int(RGB_Values[a]) for a in range (0,3)]

    return (
        New_RGB_Values[0],      ## Red value
        New_RGB_Values[1],      ## Green value
        New_RGB_Values[2]       ## Blue value
    )

## Returns a Suffix in the form " {Year}_{Month}_{Day} {Hour}_{Min} {Duplication_Suffix}"
## Each value besides Duplication_Suffix will have consistant sizes so they sort well e.g. Jan would be "01" not "1"
## This is only invoked if the writing funcitons are trying to create a file that already exists
def Suffix_Generation(Duplication_Number):

    Time_Creation = (f"{time.localtime().tm_year}_"
                +f"{time.localtime().tm_mon if len(str(time.localtime().tm_mon))==2 else str(0)+str(time.localtime().tm_mon)}_"
                +f"{time.localtime().tm_mday if len(str(time.localtime().tm_mday))==2 else str(0)+str(time.localtime().tm_mday)} at "
                +f"{time.localtime().tm_hour if len(str(time.localtime().tm_hour))==2 else str(0)+str(time.localtime().tm_hour)}_"
                +f"{time.localtime().tm_min if len(str(time.localtime().tm_min))==2 else str(0)+str(time.localtime().tm_min)}"
    )

    if Duplication_Number != 0:
        Duplication_Suffix = f" _{Duplication_Number}_"
    else:
        Duplication_Suffix = ""

    return f"{Time_Creation}{Duplication_Suffix}"
 
## These two functions open a given file PGM or PPM file and converts it into a List
## The Mandelbrot function will convert ALL of the image into a List
## The Gradient function will only convert the first line of pixels into a List
def Open_PGM_as_List(File_Name_PGM):
 
    with open(File_Name_PGM, "rb") as Reading_File:
        List_From_PGM = [[" ", [0, 0], 0],[]]
        List_From_PGM[0][0] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'").removesuffix("#")
        List_From_PGM[0][1] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'").split(" ")
        List_From_PGM[0][1][0], List_From_PGM[0][1][1] = int(List_From_PGM[0][1][0]), int(List_From_PGM[0][1][1])
        List_From_PGM[0][2] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'")
        while True:
            Value = Reading_File.read(2)
            if not Value:
                break
            List_From_PGM[1].append(int.from_bytes(Value))

    return List_From_PGM

def Open_PPM_as_List(File_Name_PPM):

    with open(File_Name_PPM, "rb") as Reading_File:
        List_From_PPM = [[" ", [0, 0], 0],[]]
        List_From_PPM[0][0] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'").removesuffix("#")
        List_From_PPM[0][1] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'").split(" ")
        List_From_PPM[0][1][0], List_From_PPM[0][1][1] = int(List_From_PPM[0][1][0]), int(List_From_PPM[0][1][1])
        List_From_PPM[0][2] = str(Reading_File.readline()).removeprefix("b'").removesuffix("\\n'")
        while True:
            Value1 = Reading_File.read(1)
            Value2 = Reading_File.read(1)
            Value3 = Reading_File.read(1)
            if not Value1:
                break
            List_From_PPM[1].append((Value1+Value2+Value3))

    return List_From_PPM

## This take a Mandelbrot Value List and a Gradient Color List and writes a PPM file
def Convert_Mandel_Iter_List_To_PPM(
    Mandel_List,
    PPM_List
    ):

    Single_Line_List = [PPM_List[1][i] for i in range (0, PPM_List[0][1][0])]
    New_PPM_Image_Bytes = b"".join([Single_Line_List[x%PPM_List[0][1][0]] if x != Mandel_List [0][2] else b"\x00\x00\x00" for x in Mandel_List[1]])

    New_PPM_Header_String= f"P6\n{Mandel_List[0][1][0]} {Mandel_List[0][1][1]}\n{PPM_List[0][2]}\n"
    if len(New_PPM_Header_String)%2 == 0:
        New_PPM_Header_String = f"P6#\n{Mandel_List[0][1][0]} {Mandel_List[0][1][1]}\n{PPM_List[0][2]}\n"

    New_PPM_Image_Data = bytes(New_PPM_Header_String, "utf-8") + New_PPM_Image_Bytes

    return New_PPM_Image_Data

## Returns a byte array with values of the RGB Pixels of a gradient
## It is only one line long though so if it is used to save a gradient it needs to added up multiple times to give a height to the resulting image
def Create_Gradient_PPM_List(
    HSV_or_RGB:str,
    Color_Functions:tuple,
    Image_Dimension:tuple
):

    Mod_Color_Functions = ["Mod_Hue_or_Red_Function", "Mod_Sat_or_Green_Function", "Mod_Val_or_Blue_Function"]

    ## Creates modded strings that replaces all values of "x" with a "(x*Image_Dimension[2]/Image)"
    ## This allows the Test gradient function to display stretched or compresed gradient version of the actual gradient in a 500 by 50 image
    for Func_Num in range(0,3):
        if Image_Dimension[0] == Image_Dimension[2]:
            Mod_Color_Functions[Func_Num] = Color_Functions[Func_Num]
            continue
        Mod_Func = ""
        for a in Color_Functions[Func_Num]:
            if a != "x":
                Mod_Func += a
            else:
                Mod_Func += f"(x*{Image_Dimension[0]}/{Image_Dimension[2]})"
        Mod_Color_Functions[Func_Num] = Mod_Func

    ## Creating the PPM image data with HSV functions and an HSV to RGB converter
    if HSV_or_RGB == "HSV":
        Gradient_Bytes = [
            int.to_bytes((RGB_Values := Convert_HSV_To_RGB(
            eval(Mod_Color_Functions[0]),
            eval(Mod_Color_Functions[1]),
            eval(Mod_Color_Functions[2])
            ))[0])+
            int.to_bytes(RGB_Values[1])+
            int.to_bytes(RGB_Values[2]) for x in range(0, Image_Dimension[2])
            ]

    ## Creating the PPM image data with RGB functions
    elif HSV_or_RGB == "RGB":
        Gradient_Bytes = [
            int.to_bytes((RGB_Values := Bounding_RGB_Values(
            eval(Mod_Color_Functions[0]),
            eval(Mod_Color_Functions[1]),
            eval(Mod_Color_Functions[2])
            ))[0])+
            int.to_bytes(RGB_Values[1])+
            int.to_bytes(RGB_Values[2]) for x in range(0, Image_Dimension[2])
            ]

    return Gradient_Bytes

## This returns the number of itterations required to go throught the mandelbrot function in order to escape past 4
## It only goes to the given Max_Iter and if it gets there it just returns that instead
@njit
def Recursion_Depth(Complex_Number_Vals, Max_Iter):
    Current_Real, Current_Imag = 0 ,0
    for Current_Iter in range (0, Max_Iter):
        if Current_Real*Current_Real + Current_Imag*Current_Imag > 4:
            return Current_Iter
        Current_Real, Current_Imag = (Current_Real*Current_Real-Current_Imag*Current_Imag + Complex_Number_Vals[0]), (2*Current_Real*Current_Imag + Complex_Number_Vals[1])
    return Max_Iter

## This Returns a List with the atributes of the PGM File in List[0] postion as a list of [["P6", (Real Resolution, Imag Resolution), Max Iteration Constant], Pixel Iteration Values]
## The Pixel Iteration values are grouped (left to right) then (up to down) in a single line of values just like a PGM
@njit
def Create_Mandel_Iter_List(
    Max_Iter:int,
    Center_Point:tuple,
    Zoom_Level:int,
    Image_Resolution:tuple,
    ):

    Mandel_Iter_List = [
        Recursion_Depth((Center_Point[0]+(4*Real_Step/Zoom_Level/Image_Resolution[1]),Center_Point[1]+(4*Imag_Step/Zoom_Level/Image_Resolution[1])), Max_Iter)
        for Imag_Step in range (int(-Image_Resolution[1]/2), int(Image_Resolution[1]/2)) for Real_Step in range (int(-Image_Resolution[0]/2), int(Image_Resolution[0]/2))
    ]

    return Mandel_Iter_List


def Test_Gradient():

    Test_Gradient_Bytes_list_Mod = Create_Gradient_PPM_List(
            HSV_or_RGB_TTK.get(),
            (Hue_or_Red_Function_TTK.get(),
            Sat_or_Green_Function_TTK.get(),
            Val_or_Blue_Function_TTK.get()),
            (Gradient_Length_TTK.get(), 50, 500),
        )
    Test_Gradient_Bytes_Mod = b"".join(Test_Gradient_Bytes_list_Mod)
    Test_Gradient_Header_Mod = f"P6\n500 50\n255\n"
    Test_Gradient_Data_Mod = bytes(Test_Gradient_Header_Mod, "utf-8")
    for y in range (0,50):
        Test_Gradient_Data_Mod += Test_Gradient_Bytes_Mod

    Gradient_Image_Reference.configure(data=Test_Gradient_Data_Mod, format="ppm")

    Test_Gradient_Bytes_list = Create_Gradient_PPM_List(
            HSV_or_RGB_TTK.get(),
            (Hue_or_Red_Function_TTK.get(),
            Sat_or_Green_Function_TTK.get(),
            Val_or_Blue_Function_TTK.get()),
            (Gradient_Length_TTK.get(), 50, Gradient_Length_TTK.get()),
        )
    Test_Gradient_List = [["P6", (Gradient_Length_TTK.get(), 1), 255], Test_Gradient_Bytes_list]
    Gradient_Test_Bytes_List_TTK.set(Test_Gradient_List)

    return None

def Test_Mandelbrot():

    Test_Mandel_Iter_List = Create_Mandel_Iter_List(
        Mandelbrot_Max_Iter_TTK.get(),
        (Mandelbrot_Center_Real_TTK.get(), Mandelbrot_Center_Imag_TTK.get()),
        (Mandelbrot_Zoom_TTK.get()/100),
        (480, 270)
        )
    Test_Mandelbrot_List = [["P5", (480, 270), Mandelbrot_Max_Iter_TTK.get()], Test_Mandel_Iter_List]

    Mandelbrot_Test_Iter_List.set(value=Test_Mandelbrot_List)

    Test_Mandelbrot_Data = Convert_Mandel_Iter_List_To_PPM(Test_Mandelbrot_List, Gradient_Test_Bytes_List_TTK.get())

    Mandelbrot_Image_Reference.configure(data=Test_Mandelbrot_Data, format="ppm")

    return None

## Saves the current Gradient with the actual length requested (Testing the gradient would always generate a 500 length image so it can be viewed)
def Save_Last_Gradient():

    if Gradient_Name_Last_TTK.get() == f"Gradient {Suffix_Generation(Duplication_Number_Grad_TTK.get())}":
        Duplication_Number_Grad_TTK.set(value=Duplication_Number_Grad_TTK.get()+1)
        New_PPM_Name = f"Gradient {Suffix_Generation(Duplication_Number_Grad_TTK.get())}"
    else:
        Duplication_Number_Grad_TTK.set(value=0)
        New_PPM_Name = f"Gradient {Suffix_Generation(0)}"

    New_Gradient_Bytes = b"".join(Create_Gradient_PPM_List(
        HSV_or_RGB_TTK.get(),
        (Hue_or_Red_Function_TTK.get(),
        Sat_or_Green_Function_TTK.get(),
        Val_or_Blue_Function_TTK.get()),
        (Gradient_Length_TTK.get(), 50, Gradient_Length_TTK.get())
    ))

    New_Gradient_Header = f"P6\n{Gradient_Length_TTK.get()} 50\n255\n"
    if len(New_Gradient_Header)%2 == 0:
        New_Gradient_Header = f"P6#\n{Gradient_Length_TTK.get()} 50\n255\n"

    New_Gradient_File = bytes(New_Gradient_Header, "utf-8")

    for y in range (0, 50):
        New_Gradient_File+=New_Gradient_Bytes

    Gradient_Name_Last_TTK.set(value=New_PPM_Name)

    with open(f"{Current_Program_Location}\\Images\\Gradient PPMs\\{New_PPM_Name}.ppm", "wb") as Gradient_Saved:
        Gradient_Saved.write(New_Gradient_File)

    return None

def Save_Last_Mandelbrot():

    if Mandelbrot_Name_Last_TTK.get() == f"Mandelbrot {Suffix_Generation(Duplication_Number_Mand_TTK.get())}":
        Duplication_Number_Mand_TTK.set(value=Duplication_Number_Mand_TTK.get()+1)
        New_PPM_Name = f"Mandelbrot {Suffix_Generation(Duplication_Number_Mand_TTK.get())}"
    else:
        Duplication_Number_Mand_TTK.set(value=0)
        New_PPM_Name = f"Mandelbrot {Suffix_Generation(0)}"

    Mandelbrot_Name_Last_TTK.set(New_PPM_Name)

    if Alternate_Gradient_TTK.get() == "":
        if Gradient_Name_Last_TTK.get() == "Test Gradient":

            Saved_Mandelbrot_PPM_Data = Convert_Mandel_Iter_List_To_PPM(
                [["P5", (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get()), Mandelbrot_Max_Iter_TTK.get()],Create_Mandel_Iter_List(
                Mandelbrot_Max_Iter_TTK.get(),
                (Mandelbrot_Center_Real_TTK.get(), Mandelbrot_Center_Imag_TTK.get()),
                (Mandelbrot_Zoom_TTK.get()/100),
                (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get())
                )],

                Gradient_Test_Bytes_List_TTK.get()
            )
        else:

            Saved_Mandelbrot_PPM_Data = Convert_Mandel_Iter_List_To_PPM(
                [["P5", (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get()), Mandelbrot_Max_Iter_TTK.get()],Create_Mandel_Iter_List(
                Mandelbrot_Max_Iter_TTK.get(),
                (Mandelbrot_Center_Real_TTK.get(), Mandelbrot_Center_Imag_TTK.get()),
                (Mandelbrot_Zoom_TTK.get()/100),
                (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get())
                )],
                Open_PPM_as_List(f"{Current_Program_Location}\\Images\\Gradient PPMs\\{Gradient_Name_Last_TTK.get()}")
            )
    else:
        Saved_Mandelbrot_PPM_Data = Convert_Mandel_Iter_List_To_PPM(
                [["P5", (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get()), Mandelbrot_Max_Iter_TTK.get()],Create_Mandel_Iter_List(
                Mandelbrot_Max_Iter_TTK.get(),
                (Mandelbrot_Center_Real_TTK.get(), Mandelbrot_Center_Imag_TTK.get()),
                (Mandelbrot_Zoom_TTK.get()/100),
                (Saved_Mandel_Resolution_Real_TTK.get(), Saved_Mandel_Resolution_Imag_TTK.get()),
                New_PPM_Name
                )],
                Open_PPM_as_List(f"{Current_Program_Location}\\Images\\Gradient PPMs\\{Alternate_Gradient_TTK.get()}")
            )
    with open(f"{Current_Program_Location}\\Images\\Mandelbrot PPMs\\{New_PPM_Name}.ppm", "wb") as Mandelbrot_Saved:
        Mandelbrot_Saved.write(Saved_Mandelbrot_PPM_Data)

    return None

## This recolors the current Mandelbrot test image with a new color scheme.
def Re_Color_Mandelbrot():
    try:
        Alternate_Gradient_List = Open_PPM_as_List(f"{Current_Program_Location}\\Images\\Gradient PPMs\\{Alternate_Gradient_TTK.get()}.ppm")
        Current_Mandelbrot_Iter_List = Mandelbrot_Test_Iter_List.get()
        Mandelbrot_Image_Reference.configure(data=Convert_Mandel_Iter_List_To_PPM(Current_Mandelbrot_Iter_List, Alternate_Gradient_List), format="ppm")
    except:
        Test_Gradient()
        Alternate_Gradient_List = Gradient_Test_Bytes_List_TTK.get()
        Current_Mandelbrot_Iter_List = Mandelbrot_Test_Iter_List.get()
        Mandelbrot_Image_Reference.configure(data=Convert_Mandel_Iter_List_To_PPM(Current_Mandelbrot_Iter_List, Alternate_Gradient_List), format="ppm")
    return None

def Set_RGB():
    HSV_or_RGB_TTK.set(value = "RGB")

def Set_HSV():
    HSV_or_RGB_TTK.set(value="HSV")

def Zoom_In_Or_Out(Zoom_Amount):
    if (Real_Pointer_Val:=Base_Window.winfo_pointerx()-Mandelbrot_Image_Label.winfo_rootx()-2) < 0 or Real_Pointer_Val > 479:
        return
    if (Imag_Pointer_Val:=Base_Window.winfo_pointery()-Mandelbrot_Image_Label.winfo_rooty()-2) < 0 or Imag_Pointer_Val > 269:
        return
    Mandelbrot_Center_Real_TTK.set(value=(Cursor_Real_Val := 4*(Real_Pointer_Val-240)/(Mandelbrot_Zoom_TTK.get()/100)/270)+Mandelbrot_Center_Real_TTK.get())
    Mandelbrot_Center_Imag_TTK.set(value=(Cursor_Imag_Val := 4*(Imag_Pointer_Val-135)/(Mandelbrot_Zoom_TTK.get()/100)/270)+Mandelbrot_Center_Imag_TTK.get())
    New_Zoom = int(Mandelbrot_Zoom_TTK.get()*Zoom_Amount)
    Mandelbrot_Zoom_TTK.set(value=New_Zoom if New_Zoom>100 else 100)

    Test_Mandel_Iter_List = Create_Mandel_Iter_List(
        Mandelbrot_Max_Iter_TTK.get(),
        (Mandelbrot_Center_Real_TTK.get(), Mandelbrot_Center_Imag_TTK.get()),
        (Mandelbrot_Zoom_TTK.get()/100),
        (480, 270)
        )
    Test_Mandelbrot_List = [["P5", (480, 270), Mandelbrot_Max_Iter_TTK.get()], Test_Mandel_Iter_List]

    Mandelbrot_Test_Iter_List.set(value=Test_Mandelbrot_List)

    Test_Mandelbrot_Data = Convert_Mandel_Iter_List_To_PPM(Test_Mandelbrot_List, Gradient_Test_Bytes_List_TTK.get())

    Mandelbrot_Image_Reference.configure(data=Test_Mandelbrot_Data, format="ppm")

Placeholder_Gradient_Image_List = Open_PPM_as_List(f"{Current_Program_Location}\\Images\\Gradient PPMs\\Gradient Image Will Go Here.ppm")
Placeholder_Gradient_Image_Data = bytes(f"{Placeholder_Gradient_Image_List[0][0]}\n{Placeholder_Gradient_Image_List[0][1][0]} {Placeholder_Gradient_Image_List[0][1][1]}\n{Placeholder_Gradient_Image_List[0][2]}\n", "utf-8")+b"".join(Placeholder_Gradient_Image_List[1])

Placeholder_Mandelbrot_Image_List = Open_PPM_as_List(f"{Current_Program_Location}\\Images\\Mandelbrot PPMs\\Mandel Image Will Go Here.ppm")
Placeholder_Mandelbrot_Image_Data = bytes(f"{Placeholder_Mandelbrot_Image_List[0][0]}\n{Placeholder_Mandelbrot_Image_List[0][1][0]} {Placeholder_Mandelbrot_Image_List[0][1][1]}\n{Placeholder_Mandelbrot_Image_List[0][2]}\n", "utf-8")+b"".join(Placeholder_Mandelbrot_Image_List[1])

Main_Program = TTK.Tk()

## These are the various Windows for dividing up the program
Base_Window = TTK.Frame(Main_Program, padx=25, pady=25)
Base_Window.grid(column=0, row=0)
Picture_Window = TTK.Frame(Base_Window, padx=25, pady=25)
Picture_Window.grid(column=0, row=0, columnspan=2)
Options_Window_Gradient = TTK.Frame(Base_Window, padx=25, pady=25)
Options_Window_Gradient.grid(column=0, row=1)
Buttons_Window_Gradient = TTK.Frame(Base_Window, padx=25, pady=25)
Buttons_Window_Gradient.grid(column=0, row=2)
Options_Window_Mandel = TTK.Frame(Base_Window, padx=25, pady=25)
Options_Window_Mandel.grid(column=1, row=1)
Buttons_Window_Mandel = TTK.Frame(Base_Window, padx=25, pady=25)
Buttons_Window_Mandel.grid(column=1, row=2)

## These are all the Variables I use in the program
HSV_or_RGB_TTK = TTK.StringVar(Base_Window, value="HSV")

Hue_or_Red_Function_TTK = TTK.StringVar(Base_Window)
Sat_or_Green_Function_TTK = TTK.StringVar(Base_Window)
Val_or_Blue_Function_TTK = TTK.StringVar(Base_Window)

Gradient_Length_TTK = TTK.IntVar(Base_Window, 500)
Gradient_Name_Last_TTK = TTK.StringVar(Base_Window, value="Test Gradient")
Duplication_Number_Grad_TTK = TTK.IntVar(Base_Window, value=0)
Gradient_Test_Bytes_List_TTK = TTK.Variable(Base_Window, value=[0])
Gradient_Image_Bytes_TTK = TTK.Variable(Base_Window, value=b'')

Mandelbrot_Name_Last_TTK = TTK.StringVar(Base_Window)
Duplication_Number_Mand_TTK = TTK.IntVar(Base_Window, value=0)
Mandelbrot_Center_Real_TTK = TTK.DoubleVar(Base_Window, value=0)
Mandelbrot_Center_Imag_TTK = TTK.DoubleVar(Base_Window, value=0)
Mandelbrot_Zoom_TTK = TTK.IntVar(Base_Window, value=100)
Mandelbrot_Zoom_Step_In_TTK = TTK.DoubleVar(Base_Window, value=2)
Mandelbrot_Zoom_Step_Out_TTK = TTK.DoubleVar(Base_Window, value=.5)
Mandelbrot_Max_Iter_TTK = TTK.IntVar(Base_Window, value=1001)
Alternate_Gradient_TTK = TTK.StringVar(Base_Window)
Saved_Mandel_Resolution_Real_TTK = TTK.IntVar(Base_Window, 1920)
Saved_Mandel_Resolution_Imag_TTK = TTK.IntVar(Base_Window, 1080)
Mandelbrot_Test_Iter_List = TTK.Variable(Base_Window, value=[0])
Mandel_Image_Bytes_TTK = TTK.Variable(Base_Window, value=b'')


## These are the the Gradient preview and Mandelbrot Preview respectively
Gradient_Image_Reference = TTK.PhotoImage(data=Placeholder_Gradient_Image_Data, format="ppm")
Gradient_Image_Label = TTK.Label(Picture_Window, image=Gradient_Image_Reference, width=500, height=50)
Gradient_Image_Label.grid(column=0, row=1)

Mandelbrot_Image_Reference = TTK.PhotoImage(data=Placeholder_Mandelbrot_Image_Data, format="ppm")
Mandelbrot_Image_Label = TTK.Label(Picture_Window, image=Mandelbrot_Image_Reference, width=480, height=270, takefocus=True)
Mandelbrot_Image_Label.bind("<Button 1>",lambda event:Zoom_In_Or_Out(Mandelbrot_Zoom_Step_In_TTK.get()))
Mandelbrot_Image_Label.bind("<Button 3>",lambda event:Zoom_In_Or_Out(Mandelbrot_Zoom_Step_Out_TTK.get()))

Mandelbrot_Image_Label.grid(column=0, row=0)

## These are the entries ascociated with the Gradient image
HSVorRGBLabel = TTK.Label(Options_Window_Gradient, text="HSV or RGB", width=12)
HSVorRGBLabel.grid(column=0, row=0, pady=5)
RGB_Var = TTK.Button(Options_Window_Gradient, text="RGB", command=Set_RGB)
RGB_Var.grid(column=2, row=0, pady=5)
HSV_Var = TTK.Button(Options_Window_Gradient, text="HSV", command=Set_HSV)
HSV_Var.grid(column=1, row=0, pady=5)

HorRFuncLabel = TTK.Label(Options_Window_Gradient, text="H/R Func", width=12)
HorRFuncLabel.grid(column=0, row=1, pady=5)
HorRFunc = TTK.Entry(Options_Window_Gradient, textvariable=Hue_or_Red_Function_TTK, width=25)
HorRFunc.grid(column=1, row=1, columnspan=2, pady=5)

SorGFuncLabel = TTK.Label(Options_Window_Gradient, text="S/G Func", width=12)
SorGFuncLabel.grid(column=0, row=2, pady=5)
SorGFunc = TTK.Entry(Options_Window_Gradient, textvariable=Sat_or_Green_Function_TTK, width=25)
SorGFunc.grid(column=1, row=2, columnspan=2, pady=5)

VorBFuncLabel = TTK.Label(Options_Window_Gradient, text="V/B Func", width=12)
VorBFuncLabel.grid(column=0, row=3, pady=5)
VorBFunc = TTK.Entry(Options_Window_Gradient, textvariable=Val_or_Blue_Function_TTK, width=25)
VorBFunc.grid(column=1, row=3, columnspan=2, pady=5)

Gradient_Length_Label = TTK.Label(Options_Window_Gradient, text="Saved Length", width=12)
Gradient_Length_Label.grid(column=0, row=4, pady=5)
Gradient_Length = TTK.Entry(Options_Window_Gradient, textvariable=Gradient_Length_TTK, width=25)
Gradient_Length.grid(column=1, row=4, columnspan=2, pady=5)


## These are the buttons ascociated with the Gradient image
Test_Gradient_Functions = TTK.Button(Buttons_Window_Gradient, text="Test Gradient", command=Test_Gradient, width=12)
Test_Gradient_Functions.grid(column=0, row=0, padx=10)
Save_Gradient_Functions = TTK.Button(Buttons_Window_Gradient, text="Save Gradient", command=Save_Last_Gradient, width=12)
Save_Gradient_Functions.grid(column=2, row=0, padx=10)
Load_Gradient_Functions = TTK.Button(Buttons_Window_Gradient, text="Load Gradient", width=12)
Load_Gradient_Functions.grid(column=1, row=0, padx=10)

## These are the entries ascociated with the Mandelbrot image
Mandelbrot_Center_Label = TTK.Label(Options_Window_Mandel, text="Center Cordinates (x+iy)")
Mandelbrot_Center_Label.grid(column=0, row=0, pady=5)
Mandelbrot_Center_Real = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Center_Real_TTK)
Mandelbrot_Center_Real.grid(column=1, row=0)
Mandelbrot_Center_Imag = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Center_Imag_TTK)
Mandelbrot_Center_Imag.grid(column=2, row=0)

Mandelbrot_Zoom_Label = TTK.Label(Options_Window_Mandel, text="Zoom Level")
Mandelbrot_Zoom_Label.grid(column=0, row=1, pady=5)
Mandelbrot_Zoom = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Zoom_TTK)
Mandelbrot_Zoom.grid(column=1, row=1, columnspan=2)

Mandelbrot_Zoom_Step_Label = TTK.Label(Options_Window_Mandel, text="Zoom Amount (In/Out)")
Mandelbrot_Zoom_Step_Label.grid(column=0, row=2, pady=5)
Mandelbrot_Zoom_Step_In = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Zoom_Step_In_TTK)
Mandelbrot_Zoom_Step_In.grid(column=1, row=2)
Mandelbrot_Zoom_Step_Out = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Zoom_Step_Out_TTK)
Mandelbrot_Zoom_Step_Out.grid(column=2, row=2)

Mandelbrot_Resolution_Label = TTK.Label(Options_Window_Mandel, text="Resolution")
Mandelbrot_Resolution_Label.grid(column=0, row=3, pady=5)
Mandelbrot_Resolution_Real = TTK.Entry(Options_Window_Mandel, textvariable=Saved_Mandel_Resolution_Real_TTK)
Mandelbrot_Resolution_Real.grid(column=1, row=3)
Mandelbrot_Resolution_Imag = TTK.Entry(Options_Window_Mandel, textvariable=Saved_Mandel_Resolution_Imag_TTK)
Mandelbrot_Resolution_Imag.grid(column=2, row=3)

Different_Gradient_Label = TTK.Label(Options_Window_Mandel, text="Alt Gradient")
Different_Gradient_Label.grid(column=0, row=4, pady=5)
Different_Gradient = TTK.Entry(Options_Window_Mandel, textvariable=Alternate_Gradient_TTK, width= 35)
Different_Gradient.grid(column=1, row=4, columnspan=2)

Max_Iteration_Level_Label = TTK.Label(Options_Window_Mandel, text="Max Iteration")
Max_Iteration_Level_Label.grid(column=0, row=5, pady=5)
Max_Iteration_Level = TTK.Entry(Options_Window_Mandel, textvariable=Mandelbrot_Max_Iter_TTK, width= 35)
Max_Iteration_Level.grid(column=1, row=5, columnspan=2)

## These are the entries ascociated with the Mandelbrot image
Test_Mandelbrot_Image = TTK.Button(Buttons_Window_Mandel, text="Test new Mandelbrot", command=Test_Mandelbrot)
Test_Mandelbrot_Image.grid(column=0, row=0, padx=15)
Re_Color_Mandelbrot_Image = TTK.Button(Buttons_Window_Mandel, text="Test alternate Gradient", command=Re_Color_Mandelbrot)
Re_Color_Mandelbrot_Image.grid(column=1, row=0, padx=15)
Save_Mandelbrot_Image = TTK.Button(Buttons_Window_Mandel, text="Save current Mandelbrot", command=Save_Last_Mandelbrot)
Save_Mandelbrot_Image.grid(column=2, row=0, padx=15)

Main_Program.mainloop()
